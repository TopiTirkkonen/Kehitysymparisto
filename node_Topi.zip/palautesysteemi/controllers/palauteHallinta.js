var Palaute = require('../models/palaute'); 

exports.palaute_lista = function(req,res,next) { 
    var palauteLista=[]; 
    Palaute.haeKaikkiPalautteet(function(err, rows, fields) {  
        if (err) {  
        return next(err); } 
        for (var i = 0; i < rows.length; i++) { 

            // Create an object to save current row's data 
            var palaute = { 
                'id':rows[i].id, 
                'otsikko':rows[i].otsikko, 
                'teksti':rows[i].teksti, 
                'kirjoittaja':rows[i].kirjoittaja, 
                'paivamaara':rows[i].paivamaara, 
            } 
            // Add object into array 
            palauteLista.push(palaute); 
        } 

            // Render index.pug page using array  
        res.render('palaute', {title:'Palautteet',palauteLista:palauteLista}); 
    }); 
}; 

exports.palaute_create_get = function(req, res, next) {      
    res.render('palaute_form', { title: 'Anna palaute' });
};

// Handle Task create on POST 
exports.palaute_create_post = function(req, res, next) {
    
    
    //Check that the Title field is not empty
    req.checkBody('otsikko', 'vaaditaan otsikko').notEmpty(); 
    req.checkBody('teksti', 'vaaditaan palaute').notEmpty(); 
    req.checkBody('kirjoittaja', 'vaaditaan kirjoittaja').notEmpty(); 
    
    //Trim and escape the name field. 
    req.sanitize('otsikko').escape();
    req.sanitize('otsikko').trim();
    req.sanitize('teksti').escape();
    req.sanitize('teksti').trim();
    req.sanitize('kirjoittaja').escape();
    req.sanitize('kirjoittaja').trim();
    
    
    
    //Run the validators
    var errors = req.validationErrors();
    
    var palaute = 
      { id:'',
		otsikko: req.body.otsikko,
		teksti: req.body.teksti,
		kirjoittaja: req.body.kirjoittaja,
		paivamaara: '2018-12-12 15:00:00.000000'
       };
    
    if (errors) {
        //If there are errors render the form again, passing the previously entered values and errors
        res.render('palaute_form', { title: 'Anna palaute', palaute: palaute, errors: errors});
    return;
    } 
    else {

        Palaute.lisaaPalaute(palaute,function(err){
            if(err) {return next(err);}
            res.redirect("/Palautteet");
        });
        
    }
};