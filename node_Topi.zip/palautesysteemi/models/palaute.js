var db = require('../lib/dbconn'); //reference of dbconnection.js 

var Palaute = { 
    haeKaikkiPalautteet: function(callback) { 
    return db.query("select * from palautteet", callback); 
  }, 
  haeIdPalaute: function(id, callback) { 
    return db.query("select * from palautteet where id=?", [id], callback); 
  }, 
  lisaaPalaute: function(Palaute, callback) { 
    return db.query("insert into palautteet values(NULL,?,?,?,?)", [Palaute.otsikko, Palaute.teksti, Palaute.kirjoittaja, Palaute.paivamaara], callback); 
  }, 
  poistaPalaute: function(id, callback) { 
    return db.query("delete from palautteet where id=?", [id], callback); 
  }, 
  paivitaPalaute: function(id, Palaute, callback) { 
    return db.query("update palautteet set otsikko=?,teksti=?,kirjoittaja=?,paivamaara=? where id=?", [Palaute.otsikko, Palaute.teksti, Palaute.kirjoittaja, Palaute.paivamaara, id], callback); 
  } 
}; 
module.exports = Palaute;