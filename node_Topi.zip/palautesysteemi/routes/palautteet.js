var express = require('express');  
var router = express.Router();  

var Palaute = require('../models/Palaute');  
var palaute_hallinta = require('../controllers/palauteHallinta'); 

function isAuthenticated(req, res, next) { 
  if (req.session.user) 
      return next(); 
  res.redirect('/signin'); 
} 
router.get('/',isAuthenticated, palaute_hallinta.palaute_lista);     

router.get('/lisaaPalaute', isAuthenticated, palaute_hallinta.palaute_create_get);
router.post('/lisaaPalaute',isAuthenticated, palaute_hallinta.palaute_create_post);    
//router.get('/:id', isAuthenticated,palaute_hallinta.palaute_details);

module.exports = router; 